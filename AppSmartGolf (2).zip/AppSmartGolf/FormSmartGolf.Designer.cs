﻿namespace AppSmartGolf
{
    partial class FormSmartGolf
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置 Managed 資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Series series2 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Series series3 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Title title1 = new System.Windows.Forms.DataVisualization.Charting.Title();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea2 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend2 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series4 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Series series5 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Series series6 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Title title2 = new System.Windows.Forms.DataVisualization.Charting.Title();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea3 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend3 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series7 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Series series8 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Series series9 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Title title3 = new System.Windows.Forms.DataVisualization.Charting.Title();
            this.chartAcc = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.buttonCon = new System.Windows.Forms.Button();
            this.richtextBoxCOM = new System.Windows.Forms.RichTextBox();
            this.buttonDiscon = new System.Windows.Forms.Button();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabPageAcc = new System.Windows.Forms.TabPage();
            this.tabPageVel = new System.Windows.Forms.TabPage();
            this.chartVel = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.tabPageDis = new System.Windows.Forms.TabPage();
            this.chartDis = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.label1 = new System.Windows.Forms.Label();
            this.textBoxCOM = new System.Windows.Forms.TextBox();
            this.buttonSendR = new System.Windows.Forms.Button();
            this.buttonSendDraw = new System.Windows.Forms.Button();
            this.backworkSendDraw = new System.ComponentModel.BackgroundWorker();
            this.contextMenuStripCOM = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.TSMClearCOM = new System.Windows.Forms.ToolStripMenuItem();
            ((System.ComponentModel.ISupportInitialize)(this.chartAcc)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPageAcc.SuspendLayout();
            this.tabPageVel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chartVel)).BeginInit();
            this.tabPageDis.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chartDis)).BeginInit();
            this.contextMenuStripCOM.SuspendLayout();
            this.SuspendLayout();
            // 
            // chartAcc
            // 
            this.chartAcc.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            chartArea1.AxisX.Title = "時間";
            chartArea1.AxisY.Title = "加速度";
            chartArea1.Name = "ChartAreaAcc";
            this.chartAcc.ChartAreas.Add(chartArea1);
            legend1.Name = "Legend1";
            this.chartAcc.Legends.Add(legend1);
            this.chartAcc.Location = new System.Drawing.Point(6, 3);
            this.chartAcc.Name = "chartAcc";
            series1.BorderWidth = 3;
            series1.ChartArea = "ChartAreaAcc";
            series1.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series1.Legend = "Legend1";
            series1.LegendText = "X加速度";
            series1.Name = "Series1";
            series2.BorderWidth = 3;
            series2.ChartArea = "ChartAreaAcc";
            series2.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series2.Legend = "Legend1";
            series2.LegendText = "Y加速度";
            series2.Name = "Series2";
            series3.BorderWidth = 3;
            series3.ChartArea = "ChartAreaAcc";
            series3.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series3.Legend = "Legend1";
            series3.LegendText = "Z加速度";
            series3.Name = "Series3";
            this.chartAcc.Series.Add(series1);
            this.chartAcc.Series.Add(series2);
            this.chartAcc.Series.Add(series3);
            this.chartAcc.Size = new System.Drawing.Size(578, 335);
            this.chartAcc.TabIndex = 0;
            this.chartAcc.Text = "chartAcc";
            title1.Name = "TitleAcc";
            title1.Text = "A-T圖";
            this.chartAcc.Titles.Add(title1);
            // 
            // buttonCon
            // 
            this.buttonCon.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.buttonCon.Location = new System.Drawing.Point(194, 391);
            this.buttonCon.Name = "buttonCon";
            this.buttonCon.Size = new System.Drawing.Size(60, 30);
            this.buttonCon.TabIndex = 1;
            this.buttonCon.Text = "連線";
            this.buttonCon.UseVisualStyleBackColor = true;
            this.buttonCon.Click += new System.EventHandler(this.buttonCon_Click);
            // 
            // richtextBoxCOM
            // 
            this.richtextBoxCOM.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.richtextBoxCOM.ContextMenuStrip = this.contextMenuStripCOM;
            this.richtextBoxCOM.Location = new System.Drawing.Point(6, 6);
            this.richtextBoxCOM.Name = "richtextBoxCOM";
            this.richtextBoxCOM.Size = new System.Drawing.Size(578, 332);
            this.richtextBoxCOM.TabIndex = 2;
            this.richtextBoxCOM.Text = "";
            // 
            // buttonDiscon
            // 
            this.buttonDiscon.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.buttonDiscon.Location = new System.Drawing.Point(260, 391);
            this.buttonDiscon.Name = "buttonDiscon";
            this.buttonDiscon.Size = new System.Drawing.Size(60, 30);
            this.buttonDiscon.TabIndex = 3;
            this.buttonDiscon.Text = "斷線";
            this.buttonDiscon.UseVisualStyleBackColor = true;
            this.buttonDiscon.Click += new System.EventHandler(this.buttonDiscon_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPageAcc);
            this.tabControl1.Controls.Add(this.tabPageVel);
            this.tabControl1.Controls.Add(this.tabPageDis);
            this.tabControl1.Location = new System.Drawing.Point(12, 12);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(598, 373);
            this.tabControl1.TabIndex = 4;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.richtextBoxCOM);
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(590, 344);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "訊息";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // tabPageAcc
            // 
            this.tabPageAcc.Controls.Add(this.chartAcc);
            this.tabPageAcc.Location = new System.Drawing.Point(4, 25);
            this.tabPageAcc.Name = "tabPageAcc";
            this.tabPageAcc.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageAcc.Size = new System.Drawing.Size(590, 344);
            this.tabPageAcc.TabIndex = 1;
            this.tabPageAcc.Text = "加速度";
            this.tabPageAcc.UseVisualStyleBackColor = true;
            // 
            // tabPageVel
            // 
            this.tabPageVel.Controls.Add(this.chartVel);
            this.tabPageVel.Location = new System.Drawing.Point(4, 25);
            this.tabPageVel.Name = "tabPageVel";
            this.tabPageVel.Size = new System.Drawing.Size(590, 344);
            this.tabPageVel.TabIndex = 2;
            this.tabPageVel.Text = "速度";
            this.tabPageVel.UseVisualStyleBackColor = true;
            // 
            // chartVel
            // 
            this.chartVel.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            chartArea2.AxisX.Title = "時間";
            chartArea2.AxisY.Title = "速度";
            chartArea2.Name = "ChartAreaAcc";
            this.chartVel.ChartAreas.Add(chartArea2);
            legend2.Name = "Legend1";
            this.chartVel.Legends.Add(legend2);
            this.chartVel.Location = new System.Drawing.Point(6, 5);
            this.chartVel.Name = "chartVel";
            series4.BorderWidth = 3;
            series4.ChartArea = "ChartAreaAcc";
            series4.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series4.Legend = "Legend1";
            series4.LegendText = "X加速度";
            series4.Name = "Series1";
            series5.BorderWidth = 3;
            series5.ChartArea = "ChartAreaAcc";
            series5.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series5.Legend = "Legend1";
            series5.LegendText = "Y加速度";
            series5.Name = "Series2";
            series6.BorderWidth = 3;
            series6.ChartArea = "ChartAreaAcc";
            series6.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series6.Legend = "Legend1";
            series6.LegendText = "Z加速度";
            series6.Name = "Series3";
            this.chartVel.Series.Add(series4);
            this.chartVel.Series.Add(series5);
            this.chartVel.Series.Add(series6);
            this.chartVel.Size = new System.Drawing.Size(578, 335);
            this.chartVel.TabIndex = 1;
            this.chartVel.Text = "chartVel";
            title2.Name = "TitleVel";
            title2.Text = "V-T圖";
            this.chartVel.Titles.Add(title2);
            // 
            // tabPageDis
            // 
            this.tabPageDis.Controls.Add(this.chartDis);
            this.tabPageDis.Location = new System.Drawing.Point(4, 25);
            this.tabPageDis.Name = "tabPageDis";
            this.tabPageDis.Size = new System.Drawing.Size(590, 344);
            this.tabPageDis.TabIndex = 3;
            this.tabPageDis.Text = "位移";
            this.tabPageDis.UseVisualStyleBackColor = true;
            // 
            // chartDis
            // 
            this.chartDis.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            chartArea3.AxisX.Title = "時間";
            chartArea3.AxisY.Title = "位移";
            chartArea3.Name = "ChartAreaAcc";
            this.chartDis.ChartAreas.Add(chartArea3);
            legend3.Name = "Legend1";
            this.chartDis.Legends.Add(legend3);
            this.chartDis.Location = new System.Drawing.Point(6, 5);
            this.chartDis.Name = "chartDis";
            series7.BorderWidth = 3;
            series7.ChartArea = "ChartAreaAcc";
            series7.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series7.Legend = "Legend1";
            series7.LegendText = "X加速度";
            series7.Name = "Series1";
            series8.BorderWidth = 3;
            series8.ChartArea = "ChartAreaAcc";
            series8.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series8.Legend = "Legend1";
            series8.LegendText = "Y加速度";
            series8.Name = "Series2";
            series9.BorderWidth = 3;
            series9.ChartArea = "ChartAreaAcc";
            series9.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series9.Legend = "Legend1";
            series9.LegendText = "Z加速度";
            series9.Name = "Series3";
            this.chartDis.Series.Add(series7);
            this.chartDis.Series.Add(series8);
            this.chartDis.Series.Add(series9);
            this.chartDis.Size = new System.Drawing.Size(578, 335);
            this.chartDis.TabIndex = 1;
            this.chartDis.Text = "chartDis";
            title3.Name = "TitleDis";
            title3.Text = "D-T圖";
            this.chartDis.Titles.Add(title3);
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(19, 399);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(121, 15);
            this.label1.TabIndex = 5;
            this.label1.Text = "COM Port Number:";
            // 
            // textBoxCOM
            // 
            this.textBoxCOM.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.textBoxCOM.Location = new System.Drawing.Point(146, 396);
            this.textBoxCOM.Name = "textBoxCOM";
            this.textBoxCOM.Size = new System.Drawing.Size(24, 25);
            this.textBoxCOM.TabIndex = 6;
            this.textBoxCOM.Text = "5";
            // 
            // buttonSendR
            // 
            this.buttonSendR.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.buttonSendR.Location = new System.Drawing.Point(326, 391);
            this.buttonSendR.Name = "buttonSendR";
            this.buttonSendR.Size = new System.Drawing.Size(85, 30);
            this.buttonSendR.TabIndex = 7;
            this.buttonSendR.Text = "送1個\"r\"";
            this.buttonSendR.UseVisualStyleBackColor = true;
            this.buttonSendR.Click += new System.EventHandler(this.buttonSendR_Click);
            // 
            // buttonSendDraw
            // 
            this.buttonSendDraw.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.buttonSendDraw.Location = new System.Drawing.Point(417, 391);
            this.buttonSendDraw.Name = "buttonSendDraw";
            this.buttonSendDraw.Size = new System.Drawing.Size(145, 30);
            this.buttonSendDraw.TabIndex = 8;
            this.buttonSendDraw.Text = "送100個\"r\"並畫圖";
            this.buttonSendDraw.UseVisualStyleBackColor = true;
            this.buttonSendDraw.Click += new System.EventHandler(this.buttonSendDraw_Click);
            // 
            // backworkSendDraw
            // 
            this.backworkSendDraw.DoWork += new System.ComponentModel.DoWorkEventHandler(this.backworkSendDraw_DoWork);
            this.backworkSendDraw.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(this.backworkSendDraw_RunWorkerCompleted);
            // 
            // contextMenuStripCOM
            // 
            this.contextMenuStripCOM.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.contextMenuStripCOM.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.TSMClearCOM});
            this.contextMenuStripCOM.Name = "contextMenuStripCOM";
            this.contextMenuStripCOM.Size = new System.Drawing.Size(139, 28);
            // 
            // TSMClearCOM
            // 
            this.TSMClearCOM.Name = "TSMClearCOM";
            this.TSMClearCOM.Size = new System.Drawing.Size(138, 24);
            this.TSMClearCOM.Text = "清除訊息";
            this.TSMClearCOM.Click += new System.EventHandler(this.TSMClearCOM_Click);
            // 
            // FormSmartGolf
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(622, 433);
            this.Controls.Add(this.buttonSendDraw);
            this.Controls.Add(this.buttonSendR);
            this.Controls.Add(this.textBoxCOM);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.buttonDiscon);
            this.Controls.Add(this.buttonCon);
            this.MinimumSize = new System.Drawing.Size(640, 480);
            this.Name = "FormSmartGolf";
            this.Text = "Smart Glove";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.FormSmartGolf_FormClosed);
            ((System.ComponentModel.ISupportInitialize)(this.chartAcc)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPageAcc.ResumeLayout(false);
            this.tabPageVel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.chartVel)).EndInit();
            this.tabPageDis.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.chartDis)).EndInit();
            this.contextMenuStripCOM.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataVisualization.Charting.Chart chartAcc;
        private System.Windows.Forms.Button buttonCon;
        private System.Windows.Forms.RichTextBox richtextBoxCOM;
        private System.Windows.Forms.Button buttonDiscon;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPageAcc;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBoxCOM;
        private System.Windows.Forms.Button buttonSendR;
        private System.Windows.Forms.TabPage tabPageVel;
        private System.Windows.Forms.TabPage tabPageDis;
        private System.Windows.Forms.Button buttonSendDraw;
        private System.ComponentModel.BackgroundWorker backworkSendDraw;
        private System.Windows.Forms.DataVisualization.Charting.Chart chartVel;
        private System.Windows.Forms.DataVisualization.Charting.Chart chartDis;
        private System.Windows.Forms.ContextMenuStrip contextMenuStripCOM;
        private System.Windows.Forms.ToolStripMenuItem TSMClearCOM;
    }
}


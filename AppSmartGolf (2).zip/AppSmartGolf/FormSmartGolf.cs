﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO.Ports;
using System.Threading;

namespace AppSmartGolf
{
    public partial class FormSmartGolf : Form
    {
        private SerialPort _serialPort;
        private Thread oThreadA;
        private bool isSending, ShowInform;
        private int sendCount, recieveCount;
        private int gravity;

        int scan_step;   // ms

        private int[][] acceleration;
        private double[][] velocity;
        private double[][] displacement;


        public FormSmartGolf()
        {
            InitializeComponent();
            sendCount = 0;
            recieveCount = 0;
            isSending = false;
            ShowInform = false;

            acceleration = new int[100][];
            velocity = new double[100][];
            displacement = new double[100][];
            for (int i = 0; i < 100; i++)
            {
                acceleration[i] = new int[3];
                velocity[i] = new double[3];
                displacement[i] = new double[3];
            }

            scan_step = 25;
            gravity = 60;
        }

        private void FormSmartGolf_FormClosed(object sender, FormClosedEventArgs e)
        {
            int count = 0;
            if (this._serialPort != null && this._serialPort.IsOpen)
            {
                ShowInform = false;         // 關閉顯示資訊用Thread
                while (oThreadA.IsAlive && count < 20)
                {
                    Thread.Sleep(scan_step);
                    count++;
                }
                // 清空 serial port 的緩存
                this._serialPort.DiscardInBuffer();       // RX
                this._serialPort.DiscardOutBuffer();      // TX
                this._serialPort.Close();   // 關閉COM Port
                this.richtextBoxCOM.Text = this.richtextBoxCOM.Text + "已斷線！" + Environment.NewLine;
            }
        }

        private void ReadCOM()
        {
            //char[] buffer = new char[256];
            String buffer;

            while (ShowInform && this._serialPort != null && this._serialPort.IsOpen)
            {
                //Thread.Sleep(scan_step);

                try
                {
                    buffer = this._serialPort.ReadTo("\r\n");

                    if (buffer.Length > 0) {
                        this.SetText(buffer);

                        // 送100筆中
                        if (isSending) {
                            // 儲存資料
                            String[] accTmp = buffer.Split(' ');
                            if (accTmp.Length >= 3)
                            {
                                acceleration[recieveCount][0] = Convert.ToInt32(accTmp[0], 10);
                                acceleration[recieveCount][1] = Convert.ToInt32(accTmp[1], 10);
                                acceleration[recieveCount][2] = Convert.ToInt32(accTmp[2], 10) - gravity;
                            }

                            recieveCount++;
                            if (recieveCount >= 100)
                            {
                                isSending = false;
                            }
                        }
                        else
                        {
                            if (String.Compare(buffer, "Start") == 0)
                            {
                                this.StartDraw();
                            }
                        }
                    }
                }
                catch (TimeoutException)
                {

                }
                catch (Exception exc)
                {
                    this.SetText(exc.Message);
                    break;
                }
            }

            if (ShowInform)
            {
                this.SetText("失去連線！");
                ShowInform = false;
            }
        }

        delegate void SetTextCallback(string text);
        private void SetText(string text)
        {
            // InvokeRequired required compares the thread ID of the
            // calling thread to the thread ID of the creating thread.
            // If these threads are different, it returns true.
            if (this.richtextBoxCOM.InvokeRequired)
            {
                SetTextCallback d = new SetTextCallback(SetText);
                this.Invoke(d, new object[] { text });
            }
            else
            {
                this.richtextBoxCOM.Text = this.richtextBoxCOM.Text + text + Environment.NewLine;
            }
        }

        delegate void StartDrawCallback();
        private void StartDraw()
        {
            // InvokeRequired required compares the thread ID of the
            // calling thread to the thread ID of the creating thread.
            // If these threads are different, it returns true.
            if (this.richtextBoxCOM.InvokeRequired)
            {
                StartDrawCallback d = new StartDrawCallback(StartDraw);
                this.Invoke(d, new object[] {  });
            }
            else
            {
                if (!this.backworkSendDraw.IsBusy)
                {
                    this.backworkSendDraw.RunWorkerAsync();
                }
            }
        }

        private void buttonCon_Click(object sender, EventArgs e)
        {
            if (this._serialPort == null ||
                !this._serialPort.IsOpen)
            {
                try
                {
                    this._serialPort = new SerialPort("COM" + this.textBoxCOM.Text, 9600, Parity.None, 8, StopBits.One)
                    {
                        ReadTimeout = 100,
                        WriteTimeout = 100
                    };
                    this._serialPort.Open();
                    // 清空 serial port 的緩存
                    //this._serialPort.DiscardInBuffer();       // RX
                    //this._serialPort.DiscardOutBuffer();      // TX

                    this.richtextBoxCOM.Text = this.richtextBoxCOM.Text + "成功連線至COM" + this.textBoxCOM.Text + Environment.NewLine;

                    ShowInform = true;
                    oThreadA = new Thread(new ThreadStart(ReadCOM));
                    oThreadA.Name = "A Thread";
                    oThreadA.Start();
                }
                catch (Exception exc)
                {
                    this.richtextBoxCOM.Text = this.richtextBoxCOM.Text + "連線至COM" + this.textBoxCOM.Text + "發生錯誤！" + Environment.NewLine;
                    MessageBox.Show("連線至COM" + this.textBoxCOM.Text + "發生錯誤！" + Environment.NewLine + exc.Message);
                }


            }
            else {
                MessageBox.Show("已有連線！" + this.textBoxCOM.Text);
            }
        }

        private void buttonDiscon_Click(object sender, EventArgs e)
        {
            int count = 0;
            if (this._serialPort != null && this._serialPort.IsOpen)
            {
                ShowInform = false;         // 關閉顯示資訊用Thread
                while (oThreadA.IsAlive && count < 20)
                {
                    Thread.Sleep(scan_step);
                    count++;
                }
                // 清空 serial port 的緩存
                this._serialPort.DiscardInBuffer();       // RX
                this._serialPort.DiscardOutBuffer();      // TX
                this._serialPort.Close();   // 關閉COM Port
                this.richtextBoxCOM.Text = this.richtextBoxCOM.Text + "已斷線！" + Environment.NewLine;
            }
        }

        private void buttonSendR_Click(object sender, EventArgs e)
        {
            if (this._serialPort != null && this._serialPort.IsOpen)
            {
                try
                {
                    // 清空 serial port 的緩存
                    //this._serialPort.DiscardOutBuffer();      // TX

                    this._serialPort.Write("r");
                }
                catch (TimeoutException) {
                    this.richtextBoxCOM.Text = this.richtextBoxCOM.Text + "傳送逾時！" + Environment.NewLine;
                }
                catch (Exception)
                {
                    MessageBox.Show("發生錯誤！");
                }
            }
            else
            {
                MessageBox.Show("尚未連線！");
            }
        }

        private void buttonSendDraw_Click(object sender, EventArgs e)
        {
            if (this._serialPort != null && this._serialPort.IsOpen)
            {
                if (!this.backworkSendDraw.IsBusy)
                {
                    this.backworkSendDraw.RunWorkerAsync();
                }
            }
            else
            {
                MessageBox.Show("尚未連線！");
            }

        }

        private void TSMClearCOM_Click(object sender, EventArgs e)
        {
            this.richtextBoxCOM.Text = String.Empty;
        }

        private void backworkSendDraw_DoWork(object sender, DoWorkEventArgs e)
        {
            if (this._serialPort != null && this._serialPort.IsOpen)
            {
                // 初始化變數
                for (int i = 0; i < 100; i++)
                {
                    acceleration[i][0] = 0;
                    velocity[i][0] = 0;
                    displacement[i][0] = 0;
                    acceleration[i][1] = 0;
                    velocity[i][1] = 0;
                    displacement[i][1] = 0;
                    acceleration[i][2] = 0;
                    velocity[i][2] = 0;
                    displacement[i][2] = 0;
                }
                sendCount = 0;
                recieveCount = 0;
                isSending = true;

                try
                {
                    while (this._serialPort != null && this._serialPort.IsOpen && isSending && recieveCount < 100)
                    {
                        //if (recieveCount >= sendCount) {
                            this._serialPort.Write("r");
                            sendCount++;
                        //}
                        Thread.Sleep(scan_step);
                    }
                }
                catch (TimeoutException)
                {
                    MessageBox.Show("傳送逾時！");
                }
                catch (Exception)
                {
                    MessageBox.Show("發生錯誤！");
                }
            }
            isSending = false;
        }

        private void backworkSendDraw_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            // 計算速度 距離
            velocity[0][0] = acceleration[0][0] * scan_step / 1000.0;
            velocity[0][1] = acceleration[0][1] * scan_step / 1000.0;
            velocity[0][2] = acceleration[0][2] * scan_step / 1000.0;
            displacement[0][0] = velocity[0][0] * scan_step / 1000.0;
            displacement[0][1] = velocity[0][1] * scan_step / 1000.0;
            displacement[0][2] = velocity[0][2] * scan_step / 1000.0;
            for (int i = 1; i < recieveCount; i++)
            {
                velocity[i][0] = velocity[i-1][0] + acceleration[i][0] * scan_step / 1000.0;
                velocity[i][1] = velocity[i-1][1] + acceleration[i][1] * scan_step / 1000.0;
                velocity[i][2] = velocity[i-1][2] + acceleration[i][2] * scan_step / 1000.0;
                displacement[i][0] = displacement[i-1][0] + velocity[i][0] * scan_step / 1000.0;
                displacement[i][1] = displacement[i-1][1] + velocity[i][1] * scan_step / 1000.0;
                displacement[i][2] = displacement[i-1][2] + velocity[i][2] * scan_step / 1000.0;
            }

            // 清除舊序列(加速度)
            this.chartAcc.Series[0].Points.Clear();
            this.chartAcc.Series[1].Points.Clear();
            this.chartAcc.Series[2].Points.Clear();
            // 清除舊序列(速度)
            this.chartVel.Series[0].Points.Clear();
            this.chartVel.Series[1].Points.Clear();
            this.chartVel.Series[2].Points.Clear();
            // 清除舊序列(位移)
            this.chartDis.Series[0].Points.Clear();
            this.chartDis.Series[1].Points.Clear();
            this.chartDis.Series[2].Points.Clear();

            // 設定新序列
            this.chartAcc.Series[0].Points.Add(new System.Windows.Forms.DataVisualization.Charting.DataPoint(0, 0));  // 加速度X
            this.chartAcc.Series[1].Points.Add(new System.Windows.Forms.DataVisualization.Charting.DataPoint(0, 0));  // 加速度Y
            this.chartAcc.Series[2].Points.Add(new System.Windows.Forms.DataVisualization.Charting.DataPoint(0, 0));  // 加速度Z
            this.chartVel.Series[0].Points.Add(new System.Windows.Forms.DataVisualization.Charting.DataPoint(0, 0));  // 速度X
            this.chartVel.Series[1].Points.Add(new System.Windows.Forms.DataVisualization.Charting.DataPoint(0, 0));  // 速度Y
            this.chartVel.Series[2].Points.Add(new System.Windows.Forms.DataVisualization.Charting.DataPoint(0, 0));  // 速度Z
            this.chartDis.Series[0].Points.Add(new System.Windows.Forms.DataVisualization.Charting.DataPoint(0, 0));  // 位移X
            this.chartDis.Series[1].Points.Add(new System.Windows.Forms.DataVisualization.Charting.DataPoint(0, 0));  // 位移Y
            this.chartDis.Series[2].Points.Add(new System.Windows.Forms.DataVisualization.Charting.DataPoint(0, 0));  // 位移Z
            for (int i = 0; i < recieveCount; i++ )
            {
                this.chartAcc.Series[0].Points.Add(new System.Windows.Forms.DataVisualization.Charting.DataPoint((i + 1) * scan_step / 1000.0, acceleration[i][0]));  // 加速度X
                this.chartAcc.Series[1].Points.Add(new System.Windows.Forms.DataVisualization.Charting.DataPoint((i + 1) * scan_step / 1000.0, acceleration[i][1]));  // 加速度Y
                this.chartAcc.Series[2].Points.Add(new System.Windows.Forms.DataVisualization.Charting.DataPoint((i + 1) * scan_step / 1000.0, acceleration[i][2]));  // 加速度Z
                this.chartVel.Series[0].Points.Add(new System.Windows.Forms.DataVisualization.Charting.DataPoint((i + 1) * scan_step / 1000.0, velocity[i][0]));      // 速度X
                this.chartVel.Series[1].Points.Add(new System.Windows.Forms.DataVisualization.Charting.DataPoint((i + 1) * scan_step / 1000.0, velocity[i][1]));      // 速度Y
                this.chartVel.Series[2].Points.Add(new System.Windows.Forms.DataVisualization.Charting.DataPoint((i + 1) * scan_step / 1000.0, velocity[i][2]));      // 速度Z
                this.chartDis.Series[0].Points.Add(new System.Windows.Forms.DataVisualization.Charting.DataPoint((i + 1) * scan_step / 1000.0, displacement[i][0]));  // 位移X
                this.chartDis.Series[1].Points.Add(new System.Windows.Forms.DataVisualization.Charting.DataPoint((i + 1) * scan_step / 1000.0, displacement[i][1]));  // 位移Y
                this.chartDis.Series[2].Points.Add(new System.Windows.Forms.DataVisualization.Charting.DataPoint((i + 1) * scan_step / 1000.0, displacement[i][2]));  // 位移Z
            }
        }
    }
}
